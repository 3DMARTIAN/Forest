const forestData = [
  { name: "Pohon Jati", desc: "Kayu kuat dan bernilai tinggi." },
  { name: "Pohon Pinus", desc: "Menghasilkan resin dan tumbuh di pegunungan." },
  { name: "Harimau", desc: "Predator puncak di hutan." },
  { name: "Burung Elang", desc: "Burung pemangsa dengan penglihatan tajam." },
  { name: "Pakis", desc: "Tumbuhan yang hidup di tempat lembab." }
];

const container = document.getElementById("forest-container");
const searchInput = document.getElementById("search");

function displayData(data) {
  container.innerHTML = "";
  data.forEach(item => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.innerHTML = `<h3>${item.name}</h3><p>${item.desc}</p>`;
    container.appendChild(card);
  });
}

searchInput.addEventListener("input", (e) => {
  const value = e.target.value.toLowerCase();
  const filtered = forestData.filter(item => item.name.toLowerCase().includes(value));
  displayData(filtered);
});

displayData(forestData);
