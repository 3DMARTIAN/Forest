# Website Eksplorasi Hutan

Website sederhana bertema hutan menggunakan HTML, CSS, dan JavaScript.

## Fitur
- Menampilkan flora dan fauna hutan
- Fitur pencarian
- Desain sederhana dan hijau alami

## Cara Menjalankan
Buka file index.html di browser.

## Teknologi
- HTML
- CSS
- JavaScript
